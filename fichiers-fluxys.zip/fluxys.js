j$(".dropdown-heading").hover(function(){j$('.dropdown-list',this).fadeToggle('fast');});

var myJobInsideInfoDiv = document.getElementById('jJobInsideInfo');
var myApplyButton = document.getElementById('apply_btn');
var myApplyByEmailOnlyFound = false;

if(myJobInsideInfoDiv != null && myApplyButton != null) {
  var elements = myJobInsideInfoDiv.getElementsByTagName('label');

  for (var i = 0; i < elements.length && !myApplyByEmailOnlyFound; i++) {
    var currElement = elements[i];

    if(currElement.innerHTML == 'Type of submission: Email') {
      myApplyButton.parentNode.removeChild(myApplyButton);

      var myParentElement = currElement.parentNode;
      myParentElement.removeChild(currElement);
      myParentElement.parentNode.removeChild(myParentElement);
      myApplyByEmailOnlyFound = true;
    }
  }
}

var myLogoInnerDiv = document.getElementById('logo_inner');

if(myLogoInnerDiv != null) {
  var elements = myLogoInnerDiv.getElementsByTagName('a');

  for (var i = 0; i < elements.length; i++) {
    var currElement = elements[i];

    if(currElement.href != null) {
      currElement.href = 'https://stgfluxyssa.upgrade.selectminds.com/staging/jobs/search/1295';
    }
  }
}

if(!myApplyByEmailOnlyFound) {
  var imported = document.createElement('script');
  imported.src = 'https://objectstorage.eu-frankfurt-1.oraclecloud.com/n/frrdnn3p0fb7/b/oda-native-client-sdk-js-20.6.1/o/chatbot.js';
  document.head.appendChild(imported);
}

// Luca Spinali -- 19/01/2020

//replace apply button in the header
jQuery(".job_details .info_box").appendTo(".btn-with-gradient");
//replace title in the header
jQuery(".job_details .content_header > .title").clone().appendTo(".section-header-title");
// add organic image before title for print
jQuery(".job_details #container").prepend('<div class="wrapper-print-organic-image"><img class="print-organic-image" src="/media/images/campaign/vorm4-header.png" /></div>');
// clone and place title on search
//jQuery(".jSearchTitle").clone().appendTo(".section-header-title");
//jQuery(".jSearchTitle").clone().appendTo(".section-header-title-search").text('Fluxys: your partner in gas infrastructure');
// remove the toggle before the location
jQuery(".job_details .content_header > .subtitle .loc_icon").remove();
// replace search fields in the header
jQuery("#search_hldr").appendTo(".block-search");




// keep only the location before the first coma
var locationList = jQuery(".primary_location a");
var locationListText = jQuery(locationList).text();
var locationArray = locationListText.split(',');
var locationFirstCell = locationArray[0];
var trimLocationFirstCell = jQuery.trim(locationFirstCell);
jQuery(locationList).text(trimLocationFirstCell + ' -');

// replace location in the header
if (jQuery(".v2").length) {
  jQuery(".job_details .content_header > .subtitle").appendTo(".content_header");
  // keep only the type of Working Schedule wS after ':' and not the title
  var wSList = jQuery("#G111605010618");
  var wSListText = jQuery(wSList).text();
  var wSArray = wSListText.split(':');
  var wSFirstCell = wSArray[1];
  var trimwSFirstCell = jQuery.trim(wSFirstCell);
  jQuery(wSList).text(trimwSFirstCell + ' -');
// replace Working Schedule in the header
  jQuery("#G111605010618").appendTo(".content_header");

// keep only the type of contract after ':' and not the title
  var contractList = jQuery("#G105305010618");
  var contractListText = jQuery(contractList).text();
  var contractArray = contractListText.split(':');
  var contractFirstCell = contractArray[1];
  var trimContractFirstCell = jQuery.trim(contractFirstCell);
  jQuery(contractList).text(trimContractFirstCell);
// replace Type of contract in the header
  jQuery("#G105305010618").appendTo(".content_header");

  jQuery(".double-lines-decoration").css("margin-bottom", "25px");
} else {
  jQuery(".job_details .content_header > .subtitle").appendTo(".section-header-more-informations");
  // keep only the type of Working SchedulewS after ':' and not the title
  var wSList = jQuery("#G111605010618");
  var wSListText = jQuery(wSList).text();
  var wSArray = wSListText.split(':');
  var wSFirstCell = wSArray[1];
  var trimwSFirstCell = jQuery.trim(wSFirstCell);
  jQuery(wSList).text(trimwSFirstCell + ' -');
// replace Working Schedule in the header
  jQuery("#G111605010618").appendTo(".section-header-more-informations");

// keep only the type of contract after ':' and not the title
  var contractList = jQuery("#G105305010618");
  var contractListText = jQuery(contractList).text();
  var contractArray = contractListText.split(':');
  var contractFirstCell = contractArray[1];
  var trimContractFirstCell = jQuery.trim(contractFirstCell);
  jQuery(contractList).text(trimContractFirstCell);
// replace Type of contract in the header
  jQuery("#G105305010618").appendTo(".section-header-more-informations");
}

/* place all elements after title job in content for the print */
jQuery(".section-header-more-informations").clone().insertAfter(jQuery(".job_details .content_header > .title"));



// add aria to job alert link on footer (who is lost when it is moved) to make the popup works
jQuery(".job-alert.jCommunityModal").attr("aria-haspopup", "true");

// Replace text of Parameters in the header settings
jQuery("#header_settings .settings_btn").addClass("jCommunityModal").attr("aria-haspopup", "true").attr("href","#").text("Job alert");
jQuery( ".settings_btn" ).click(function(e) {
  // avoid default a behaviour
  e.preventDefault();
});

// same code than on desktop.js except selector (target only the link on footer
// make work promo_talent_community button on Job Details page
j$(".job-alert.jCommunityModal, .settings_btn.jCommunityModal").unbind('click').click(function(event){
  var preselect = '';
  if(j$(this).attr('data-category-id')) {
    preselect += ( preselect ? '&' : '') + 'job_category_selected=' + j$(this).attr('data-category-id');
  }
  if(j$(this).attr('data-location-id')) {
    preselect += ( preselect ? '&' : '') + 'job_location_selected=' + j$(this).attr('data-location-id');
  }
  if(j$(this).attr('data-company-id')) {
    preselect += ( preselect ? '&' : '') + 'job_company_selected=' + j$(this).attr('data-company-id');
  }
  TVAPP.login.bindRegister({mode:"register"});
  TVAPP.modal.open("register_modal_tc",{},{mode:'register',context:preselect, action: event.currentTarget});
});


/* banner epic */
if (jQuery("#G130105010618").length) {
  // We take the textual value of the field which will impact on the display of the logo and we store it in a variable which will be used in the "cases" of the switch below
  var valueEpic = jQuery("#G130105010618").text();


  switch (valueEpic) {
    //The case = the text value for the Background Type field in the administration
    case 'Background Type: EPIC 1':
      // If you want another picture, just change the URL after
      jQuery(".fit-picture").attr("src", "/media/images/epic-banners/epic-1.jpg").show("fade");

      break;

    case 'Background Type: EPIC 2':
      jQuery(".fit-picture").attr("src", "/media/images/epic-banners/epic-3.jpg").show("fade");

      break;

    case 'Background Type: EPIC 3':
      jQuery(".fit-picture").attr("src", "/media/images/epic-banners/epic-4.jpg").show("fade");

      break;
    // to add a new EPIC banner, just copy/paste from Case to break; and replace the value of the case with the new one and replace the URL

    // this banner image is shown if there is no matching value for Background Type
    default:
      jQuery(".fit-picture").attr("src", "/media/images/epic-banners/epic-1.jpg").show("fade");

  }
} else {
  // if Background Type field don't exist, this banner image is shown by default
  jQuery(".fit-picture").attr("src", "/media/images/epic-banners/epic-1.jpg").show("fade");
}

/* change logo according to field company value */
if (jQuery(".field_company .field_value").length) {
  // We take the textual value of the field which will impact on the display of the logo and we store it in a variable which will be used in the "cases" of the switch below
  var valueLogo = jQuery(".field_company .field_value").text();


  switch (valueLogo) {
    //The case = the text value for the Epic field in the administration
    case 'Fluxys':
      jQuery(".logo img").attr("src", "/media/client_67_s15_r0_v1611057436338_main.png").show("fade");

      break;

    case 'Dunkerque LNG':
      jQuery(".logo img").attr("src", "/media/images/logos-affiliates/brand-outline_dunkerque-LNG-white.png").show("fade");

      break;

    case 'FluxSwiss':
      jQuery(".logo img").attr("src", "/media/images/logos-affiliates/brand-outline_fluxswiss-white.png").show("fade");
s
      break;

    case 'Fluxys Deutschland':
      jQuery(".logo img").attr("src", "/media/images/logos-affiliates/brand-outline_fluxys_Deutschland-white.png").show("fade");

      break;

    case 'Fluxys TENP':
      jQuery(".logo img").attr("src", "/media/images/logos-affiliates/brand-outline_fluxys_TENP-white.png").show("fade");

      break;

    case 'Gaz-Opale':
      jQuery(".logo img").attr("src", "/media/images/logos-affiliates/brand-outline_gaz-opale-white.png").show("fade");

      break;

    case 'GMSL':
      jQuery(".logo img").attr("src", "/media/client_67_s15_r0_v1611057436338_main.png").show("fade");

      break;

    case 'Interconnector':
      jQuery(".logo img").attr("src", "/media/images/logos-affiliates/brand-outline_interconnector-white.png").show("fade");

      break;

    case 'Transitgaz':
      jQuery(".logo img").attr("src", "/media/client_67_s15_r0_v1611057436338_main.png").show("fade");

      break;
    // this logo is shown if there is no matching value for valueEpic
    default:
      jQuery(".logo img").attr("src", "/media/client_67_s15_r0_v1611057436338_main.png").show("fade");

  }
} else {
  // if field_company field don't exist, this logo is shown by default
  jQuery(".logo img").attr("src", "/media/client_67_s15_r0_v1611057436338_main.png").show("fade");
}
/* clone logo in content for print */
jQuery("#logo_inner").clone().insertBefore(".content_header .title");

/* detect lang and put the intro in the good language */
if (jQuery('html').is(':lang(en)')) {
  // check first letter of the job title and change the intro sentence according to this one
  var titleHeader = jQuery('.title').text();
  var trimTitleHeader = jQuery.trim(titleHeader);
  var firstLetter = trimTitleHeader.charAt(0).toLowerCase();

  if((firstLetter == 'a') || (firstLetter == 'e') || (firstLetter == 'i') || (firstLetter == 'o') || (firstLetter == 'u')) {
    jQuery(".job_details .job-detail-intro").text("We're looking for an");
  }

  // replace text Apply by Apply now on the bottom of the page
  jQuery(".job_details .jApplyBtn .btn_text").text("Apply now");

} else if(jQuery('html').is(':lang(fr)')) {
  // fr
  jQuery(".job_details .job-detail-intro").text("Profil recherché : ");
  // replace text Apply by Apply now on the bottom of the page
  jQuery(".job_details .jApplyBtn .btn_text").text("Postuler maintenant");
} else {
  // nl
  jQuery(".job_details .job-detail-intro").text("Vereist profiel : ");
  // replace text Apply by Apply now on the bottom of the page
  jQuery(".job_details .jApplyBtn .btn_text").text("Nu toepassen");
}


// get current year for the credits
var year= new Date().getFullYear();
jQuery(".credits-year").text(year);


//remove class mobile on body if it is added
jQuery( "body" ).removeClass( "mobile");
jQuery( window ).resize(function() {
  jQuery( "body" ).removeClass( "mobile");
});


/* replace toggle filters */
jQuery(".toggle-filters").appendTo("#jobs_filters_title");
/* wait for ajax to stop , then excecute the code (to add filters/tags on the active content) */
jQuery(document).ajaxStop(function () {

  jQuery(".jSearchTitle").removeClass(".section-header-title");

  /* if tag are already in the content, do nothing */
  if (jQuery(".jResultsActive #jobs_filters_title a.active_row").length) {
  } else {

    jQuery(".toggle-filters").appendTo("#jobs_filters_title");

    jQuery(".jResultsActive .filter_row").each(function(index){
      /* dont add ALL FILTERS on top of search with other filters/tags */
      if (jQuery(this).hasClass("all_filter_row")) {
      } else {
        /* add filter checked on top of search and add an specific ID to the same filter/tag in left column and top */
        jQuery(this).find("a.active_row").attr("data-serial", index).clone().appendTo("#jobs_filters_title");
      }
    });
    jQuery( "#jobs_filters_title a.active_row" ).click(function() {
      /* when click a filter/tag on top of search, find the filter with same data-serial in the left column and click it */
      var serial = jQuery(this).attr("data-serial");
      jQuery("#job_search_filters .active_row");
      jQuery(".jResultsActive #job_search_filters a.active_row").each(function(){
        if (jQuery(this).attr("data-serial") == serial) {
          jQuery(this).click();
        } else {

        }
      });
    });
  }
});
/* open close filters */
jQuery( ".toggle-filters" ).click(function() {
  jQuery("body").toggleClass("open");
});

/* back button en details page */
jQuery(".back-button").prependTo(".job.details #job_details_content");
function goBack() {
  window.history.back();
}
/*jQuery( ".back-button" ).click(function() {
  goBack();
});*/

/* add print button */
jQuery(".print_btn").appendTo("#header_settings_container");
/* start print on click */
jQuery( ".print_btn" ).click(function() {
  window.print();
});

/* load script for addToAny */
var s = document.createElement("script");
s.type = "text/javascript";
s.src = "https://static.addtoany.com/menu/page.js";
jQuery("head").append(s);

